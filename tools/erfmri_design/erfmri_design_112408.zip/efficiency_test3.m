close all; clear all;

hdr_length=30.0; %second
hdr_pre=6.0; 	%second (pre-stim)
TR=2; %second
flag_hdr_canonical=0;
flag_hdr_fir=1;

load design.mat;


%%%%%%%%%%%%%%%%%%%%% specify HRF
hdr_timeVec=[0:TR:hdr_length-TR]-hdr_pre;
n_hdr=round(hdr_length/TR);
hdr_baseline_idx=find(hdr_timeVec<0);
hdr_baseline_idx=[];

if(flag_hdr_canonical)
    hhdr_timeVec=hdr_timeVec;
    hhdr_timeVec(find(hhdr_timeVec<0))=0;
    HDR=fmri_hdr(hhdr_timeVec);
    %HDR=HDR(:,1);
elseif(flag_hdr_fir)
    HDR=eye(n_hdr);
end;

hrf.timeVec=hdr_timeVec;
hrf.duration=hdr_length;
hrf.pre=hdr_pre;
hrf.hrf=HDR;

%%%%%%%%%%%%%%%%%%%%% calculating efficiency

[efficiency,param]=fmri_design_efficiency(design, hrf);